﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CompanyWen
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private int currentCompanyId = -1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                LoadData();
        }

        private void LoadData()
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                GridView1.DataSource = from VW_Company in db.VW_Companies
                                       orderby VW_Company.ChildPath
                                       select VW_Company;
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            LoadData();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.SelectedIndex = -1;
            LoadData();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var cId = GridView1.DataKeys[e.RowIndex].Value;
                Company item = db.Companies.SingleOrDefault(x => x.CompanyID == Convert.ToInt32(cId));
                db.Companies.DeleteOnSubmit(item);
                db.SubmitChanges();
            }
            LoadData();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            currentCompanyId = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);

            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {

                var cName = e.NewValues["CompanyName"];
                var cSalary = e.NewValues["Salary"];
                Company item = db.Companies.SingleOrDefault(x => x.CompanyID == currentCompanyId);
                item.CompanyName = Convert.ToString(cName);
                item.Salary = Convert.ToDecimal(cSalary);
                db.SubmitChanges();
            }
            GridView1.SelectedIndex = -1;
            LoadData();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "New")
            {
                currentCompanyId = Convert.ToInt32(GridView1.DataKeys[((GridView)e.CommandSource).SelectedIndex].Value);

                using (DataClasses1DataContext db = new DataClasses1DataContext())
                {
                    Company item = db.Companies.SingleOrDefault(x => x.CompanyID == currentCompanyId);
                    Company newItem = new Company { ParentCompanyID = item.CompanyID, CompanyName = "New", Salary=0};
                    db.Companies.InsertOnSubmit(newItem);
                    db.SubmitChanges();
                }
                GridView1.SelectedIndex = -1;
                LoadData();
            }
        }
    }
}