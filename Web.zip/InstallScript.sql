IF OBJECT_ID('dbo.Companies', 'U') IS NOT NULL
    DROP TABLE dbo.Companies
GO
CREATE TABLE Companies
(
	CompanyID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	ParentCompanyID int,
	CompanyName varchar(255) NOT NULL,
	Salary money NOT NULL DEFAULT 0
);
GO
ALTER TABLE Companies ADD CONSTRAINT fk_Companies FOREIGN KEY (ParentCompanyID) REFERENCES Companies(CompanyID)
GO
IF EXISTS (SELECT * FROM   sys.objects WHERE  object_id = OBJECT_ID(N'[dbo].[F_GET_SALARY]') AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[F_GET_SALARY]
GO 
CREATE FUNCTION F_GET_SALARY
(
	@CompanyId Int
)
RETURNS Money
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RetVal money = 0;

	;WITH r as (
			SELECT CompanyId
			FROM dbo.Companies
			WHERE ParentCompanyId = @CompanyId

			UNION ALL

			SELECT d.CompanyId 
			FROM dbo.Companies d
			INNER JOIN r ON d.ParentCompanyId = r.CompanyId
	)
	SELECT @RetVal = SUM(Salary)  FROM dbo.Companies WHERE CompanyId IN (SELECT CompanyId FROM r)
	-- Return the result of the function
	RETURN ISNULL(@RetVal, 0)

END
GO
IF EXISTS (SELECT * FROM   sys.objects WHERE  object_id = OBJECT_ID(N'[dbo].[F_GET_COMPANY_PATH]') AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[F_GET_COMPANY_PATH]
GO 
CREATE FUNCTION F_GET_COMPANY_PATH
(
	@CompanyId Int
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RetVal VARCHAR(MAX) = '';

	;WITH Paths AS 
	(
		SELECT 
			0 AS LevelId, 
			CAST(CompanyName  AS VARCHAR(MAX)) AS CompanyName, 
			CompanyId
		FROM dbo.Companies
		WHERE (ParentCompanyID IS NULL)

		UNION ALL

		SELECT 
			p.LevelId + 1 AS LevelId
			,CAST(CASE RIGHT(p.CompanyName, 1) WHEN '\' THEN p.CompanyName + c.CompanyName ELSE p.CompanyName + '\' + c.CompanyName END AS VARCHAR(MAX)) AS CompanyName
			, c.CompanyId
		FROM dbo.Companies AS c 
		INNER JOIN Paths AS p ON p.CompanyId = c.ParentCompanyId
	)
	SELECT  @RetVal = MAX(CompanyName) FROM Paths WHERE CompanyId = @CompanyId;

	-- Return the result of the function
	RETURN @RetVal;

END
GO
IF OBJECT_ID('dbo.VW_Companies') IS NOT NULL
	DROP VIEW VW_Companies
GO
CREATE VIEW VW_Companies
AS
	SELECT 
		ParentCompanyId
		, CompanyId
		, (replicate('--', DENSE_RANK() OVER (ORDER BY parentcompanyid)) + CompanyName) AS CompanyName
		, Salary
		, Salary + dbo.F_GET_SALARY(CompanyId) AS ChildSalary
		, dbo.F_GET_COMPANY_PATH(CompanyId) AS ChildPath
		, DENSE_RANK() OVER (ORDER BY parentcompanyid) as LVL
	FROM 
		dbo.Companies;
GO
INSERT INTO dbo.Companies(ParentCompanyId, CompanyName) Values(null, 'Main')
GO